//
// Created by asgrim on 19.09.24.
//

#ifndef DISTT_SYS_UTILS_H
#define DISTT_SYS_UTILS_H

#include "banking.h"


void set_lamport_time(timestamp_t timestamp);

void inc_lamport_time();

#endif //DISTT_SYS_UTILS_H
