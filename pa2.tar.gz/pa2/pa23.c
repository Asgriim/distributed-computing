#include "banking.h"

void transfer(void * parent_data, local_id src, local_id dst,
              balance_t amount)
{
    // student, please implement me
}

//int main(int argc, char * argv[])
//{
//    //bank_robbery(parent_data);
//    //print_history(all);
//
//    return 0;
//}
